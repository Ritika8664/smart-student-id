import React, { useState, useEffect } from "react";
import { QRCodeCanvas } from "qrcode.react";
import * as htmlToImage from "html-to-image";
import { saveAs } from "file-saver";

function App() {
  // Inside the same file where you already have the rest:
  const handleDeleteCard = (indexToDelete) => {
    const updated = savedCards.filter((_, index) => index !== indexToDelete);
    localStorage.setItem("cards", JSON.stringify(updated));
    setSavedCards(updated);
  };

  const [selectedTemplate, setSelectedTemplate] = useState("template1");
  const [formData, setFormData] = useState({
    name: "",
    rollNumber: "",
    classDivision: "",
    allergies: [],
    photo: null,
    rackNumber: "",
    busRoute: "",
  });
  const [photoPreview, setPhotoPreview] = useState("");
  const [showCard, setShowCard] = useState(false);
  const [savedCards, setSavedCards] = useState([]);

  useEffect(() => {
    const existingCards = JSON.parse(localStorage.getItem("cards") || "[]");
    setSavedCards(existingCards);
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handlePhotoChange = (e) => {
    const file = e.target.files[0];
    setFormData((prev) => ({
      ...prev,
      photo: file,
    }));
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setShowCard(true);
    const existingCards = JSON.parse(localStorage.getItem("cards") || "[]");
    const newCard = { ...formData, photoPreview };
    const updatedCards = [...existingCards, newCard];
    localStorage.setItem("cards", JSON.stringify(updatedCards));
    setSavedCards(updatedCards);
  };

  const downloadCard = () => {
    const cardNode = document.getElementById("id-card");
    htmlToImage
      .toPng(cardNode)
      .then((dataUrl) => {
        saveAs(dataUrl, `${formData.name}-ID.png`);
      })
      .catch((error) => {
        console.error("Download failed", error);
      });
  };

  const downloadOldCard = (card) => {
    const tempNode = document.createElement("div");
    tempNode.style.padding = "20px";
    tempNode.style.background = "#fff";
    tempNode.style.border = "2px solid #000";
    tempNode.style.width = "300px";
    tempNode.style.textAlign = "left";
    tempNode.style.fontFamily = "sans-serif";
    tempNode.innerHTML = `
      <h2>ID Card</h2>
      ${card.photoPreview ? `<img src="${card.photoPreview}" width="80" height="80" style="border-radius:8px" />` : ""}
      <p><strong>Name:</strong> ${card.name}</p>
      <p><strong>Roll Number:</strong> ${card.rollNumber}</p>
      <p><strong>Class & Division:</strong> ${card.classDivision}</p>
      <p><strong>Allergies:</strong> ${card.allergies.join(", ") || "None"}</p>
      <p><strong>Rack Number:</strong> ${card.rackNumber}</p>
      <p><strong>Bus Route:</strong> ${card.busRoute}</p>
    `;
    document.body.appendChild(tempNode);
    htmlToImage
      .toPng(tempNode)
      .then((dataUrl) => {
        saveAs(dataUrl, `${card.name}-Old-ID.png`);
        document.body.removeChild(tempNode);
      })
      .catch((error) => {
        console.error("Failed to download old card", error);
        document.body.removeChild(tempNode);
      });
  };

  return (
    <div style={{ padding: "30px", fontFamily: "sans-serif" }}>
      <h1>Smart Student ID Generator</h1>

      <form
        onSubmit={handleSubmit}
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "20px",
          maxWidth: "400px",
        }}
      >
        <div>
          <label>Name:</label>
          <input
            name="name"
            value={formData.name}
            onChange={handleChange}
            style={{ width: "100%", padding: "6px" }}
          />
        </div>

        <div>
          <label>Roll Number:</label>
          <input
            name="rollNumber"
            value={formData.rollNumber}
            onChange={handleChange}
            style={{ width: "100%", padding: "6px" }}
          />
        </div>

        <div>
          <label>Class & Division:</label>
          <select
            name="classDivision"
            value={formData.classDivision}
            onChange={handleChange}
            style={{ width: "100%", padding: "6px" }}
          >
            <option value="">Select</option>
            <option value="10-A">10-A</option>
            <option value="10-B">10-B</option>
            <option value="12-A">12-A</option>
            <option value="12-B">12-B</option>
          </select>
        </div>

        <div>
          <label>Allergies:</label>
          <details>
            <summary
              style={{
                cursor: "pointer",
                background: "#eee",
                padding: "8px",
                borderRadius: "5px",
              }}
            >
              Select Allergies
            </summary>
            <div style={{ marginTop: "10px" }}>
              {["Peanuts", "Dust", "Pollen", "Milk", "Gluten", "Seafood"].map(
                (item) => (
                  <div key={item}>
                    <label>
                      <input
                        type="checkbox"
                        value={item}
                        checked={formData.allergies.includes(item)}
                        onChange={(e) => {
                          const checked = e.target.checked;
                          setFormData((prev) => ({
                            ...prev,
                            allergies: checked
                              ? [...prev.allergies, item]
                              : prev.allergies.filter((a) => a !== item),
                          }));
                        }}
                      />
                      {` ${item}`}
                    </label>
                  </div>
                )
              )}
            </div>
          </details>
        </div>

        <div>
          <label>Photo Upload:</label>
          <input type="file" accept="image/*" onChange={handlePhotoChange} />
          {photoPreview && (
            <div style={{ marginTop: "10px" }}>
              <img
                src={photoPreview}
                alt="Preview"
                width="100"
                height="100"
                style={{ borderRadius: "8px" }}
              />
            </div>
          )}
        </div>

        <div>
          <label>Rack Number:</label>
          <input
            name="rackNumber"
            value={formData.rackNumber}
            onChange={handleChange}
            style={{ width: "100%", padding: "6px" }}
          />
        </div>

        <div>
          <label>Bus Route:</label>
          <select
            name="busRoute"
            value={formData.busRoute}
            onChange={handleChange}
            style={{ width: "100%", padding: "6px" }}
          >
            <option value="">Select</option>
            <option value="Route 1">Route 1</option>
            <option value="Route 2">Route 2</option>
            <option value="Route 3">Route 3</option>
          </select>
        </div>

        <div>
          <label>Choose Template:</label>
          <select
            value={selectedTemplate}
            onChange={(e) => setSelectedTemplate(e.target.value)}
            style={{
              width: "100%",
              padding: "8px",
              borderRadius: "5px",
              border: "1px solid #ccc",
              backgroundColor: "#f8f8f8",
            }}
          >
            <option value="template1">Blue Template</option>
            <option value="template2">Pink Template</option>
          </select>
        </div>

        <button
          type="submit"
          style={{
            padding: "10px",
            background: "#007bff",
            color: "white",
            border: "none",
            borderRadius: "4px",
            cursor: "pointer",
          }}
        >
          Generate ID
        </button>
      </form>

      {showCard && (
        <div
          id="id-card"
          style={{
            marginTop: "40px",
            padding: "20px",
            border:
              selectedTemplate === "template1"
                ? "2px solid #007bff"
                : "2px dashed #e91e63",
            borderRadius: "12px",
            width: "350px",
            background:
              selectedTemplate === "template1" ? "#e6f0ff" : "#fff0f6",
            color: selectedTemplate === "template1" ? "#000" : "#880e4f",
          }}
        >
          <h2>ID Card</h2>
          {photoPreview && (
            <img
              src={photoPreview}
              alt="Student"
              width="100"
              height="100"
              style={{ borderRadius: "8px" }}
            />
          )}
          <p>
            <strong>Name:</strong> {formData.name}
          </p>
          <p>
            <strong>Roll Number:</strong> {formData.rollNumber}
          </p>
          <p>
            <strong>Class & Division:</strong> {formData.classDivision}
          </p>
          <p>
            <strong>Allergies:</strong>{" "}
            {formData.allergies.join(", ") || "None"}
          </p>
          <p>
            <strong>Rack Number:</strong> {formData.rackNumber}
          </p>
          <p>
            <strong>Bus Route:</strong> {formData.busRoute}
          </p>
          <QRCodeCanvas
            value={`Name:${formData.name}, Roll:${formData.rollNumber}`}
            size={128}
          />

          <button
            onClick={downloadCard}
            style={{
              marginTop: "15px",
              padding: "8px 12px",
              backgroundColor: "green",
              color: "white",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
            }}
          >
            Download as PNG
          </button>
        </div>
      )}

      {savedCards.length > 0 && (
        <div style={{ marginTop: "50px" }}>
          <h2>Previously Generated ID Cards</h2>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "20px" }}>
            {savedCards.map((card, index) => (
              <div
                key={index}
                style={{
                  padding: "15px",
                  border: "1px solid #ccc",
                  borderRadius: "10px",
                  background: "#fafafa",
                  width: "300px",
                }}
              >
                {card.photoPreview && (
                  <img
                    src={card.photoPreview}
                    alt="Student"
                    width="80"
                    height="80"
                    style={{ borderRadius: "6px" }}
                  />
                )}
                <p><strong>Name:</strong> {card.name}</p>
                <p><strong>Roll Number:</strong> {card.rollNumber}</p>
                <p><strong>Class & Division:</strong> {card.classDivision}</p>
                <p><strong>Allergies:</strong> {card.allergies.join(", ") || "None"}</p>
                <p><strong>Rack Number:</strong> {card.rackNumber}</p>
                <p><strong>Bus Route:</strong> {card.busRoute}</p>
                <QRCodeCanvas
                  value={`Name:${card.name}, Roll:${card.rollNumber}`}
                  size={96}
                />

                <button
                  onClick={() => downloadOldCard(card)}
                  style={{
                    marginTop: "10px",
                    padding: "6px 10px",
                    backgroundColor: "#007bff",
                    color: "white",
                    border: "none",
                    borderRadius: "4px",
                    cursor: "pointer",
                  }}
                >
                  Download
                </button>
                <button
                    onClick={() => handleDeleteCard(index)}
                    style={{
                      padding: "6px 10px",
                      backgroundColor: "red",
                      color: "white",
                      border: "none",
                      borderRadius: "4px",
                      cursor: "pointer",
                    }}
                  >
                    Delete
                  </button>
                </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
